# mypackage
This library was created to demonstrate how to create, publish and use our own python packages